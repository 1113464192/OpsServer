package consts

import (
	"time"
)

const (
	TokenExpireDuration = time.Hour * 24 * 7
	CustomSecretKey     = "52995df076de0cf040055a9e932687209c148e75cc283f5a22c341a84e4e33dc"
)
