package consts

const (
	XorKey = 0xfA
)
