package consts

const (
	China    = 8
	HongKong = 8
	TaiWan   = 8
)
