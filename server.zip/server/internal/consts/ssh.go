package consts

const (
	SSHOpsUserId = 1
	SSHTimeout   = 20
)
