package consts

const (
	LevelError = iota
	LevelWarning
	LevelInfo
	LevelDebug
)
