package consts

const (
	OperationInstallServerType = "单服装服"
	OperationUpdateServerType  = "服务端更新"
	OperationUpdateClientType  = "客户端更新"
	OperationHostActionType    = "服务器操作"
)
