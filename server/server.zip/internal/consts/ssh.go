package consts

const (
	SSHOpsUserId   = 1
	SSHDefaultPort = "22"
)
