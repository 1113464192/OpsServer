环境
Golang-1.20.4
mysql-5.7.26
本机yum/apt工具：expect、lsof

shellScript下所有脚本给予755的权限